# IPC-Project/Assignments (30% of term grade)

## Assignment-1 (15% of term grade)
```
Milestone   Assessment      Worth Term Grade
=========== =============== ===== ==========
4           Code Correction   40%       6.0%
            Reflection        60%       9.0%
=========================== ===== ==========
                 Total:      100%      15.0%
```
****
## Assignment-2 (15% of term grade)
```
Milestone   Assessment  Worth Term Grade
=========== =========== ===== ==========
1 (Lab)     Code          10%       1.5%
----------------------- ----- ----------
2 (Home)    Code          20%       3.0%
            Reflection    20%       3.0%
----------------------- ----- ----------
3 (Lab)     Code          10%       1.5%
----------------------- ----- ----------
4 (Home)    Code          20%       3.0%
            Reflection    20%       3.0%
======================= ===== ==========
                 Total:  100%      15.0%
```
 